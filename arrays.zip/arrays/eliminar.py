""""
De la lista [10, 20, 30, 40, 50], realiza las siguientes acciones:
    Elimina el número 30. []
    Elimina el último elemento.
    Elimina el segundo elemento (índice 1).
"""

list=[10, 20, 30, 40, 50]

del list [2]

print(list)

list.pop()

print(list)

del list [1]
print(list)