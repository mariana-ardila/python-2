""""

Contar del 1 al 10:
Usa un while para imprimir los números del 1 al 10.

Contar hacia atrás:
Usa un while para imprimir los números del 10 al 1 en orden descendente.

"""
inpunt("Digite un numero")

while num>0 and num<=10:
    print("")