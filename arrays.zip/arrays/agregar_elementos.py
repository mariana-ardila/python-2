""""
#¿Cómo se agrega un elemento al final de la lista?
#¿Cómo se inserta un elemento en una posición específica?
#¿Cómo se combinan dos listas en una sola?

A una lista [10, 20, 30] agrega:

    El número 40 al final.
    El número 15 en la posición 1.
    Los números 50 y 60 al final de la lista.
"""

mi_lista=[10,20,30]

#¿Cómo se agrega un elemento al final de la lista?
mi_lista.append(40)
print(mi_lista)

#¿Cómo se inserta un elemento en una posición específica?
mi_lista.insert(1,15)
print(mi_lista)

#¿Cómo se combinan dos listas en una sola?
mi_lista.append(50)
mi_lista.append(60)
print(mi_lista)
