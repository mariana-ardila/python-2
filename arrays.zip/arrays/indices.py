lista=[10, 20, 30, 40, 50] 

#Los elementos del índice 1 al 3.
print(lista[1:3])

#Los primeros 3 elementos.
print(lista[0:3])

#Los elementos desde el índice 2 hasta el final.
print(lista[2:])
 