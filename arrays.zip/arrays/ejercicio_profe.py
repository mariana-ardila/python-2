nombres= ["ana"], ["marcela"], ["juliana"], ["mariana"], ["marcela"]

for nombre in nombres:
    print(nombres)
    
for i in range (20,50):
    print(i)
    
for i in range (20,51, 5):
    print(i)
    
for i in (10):
    print(i)