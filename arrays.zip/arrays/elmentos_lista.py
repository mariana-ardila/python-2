#Índice negativo: Accede a los elementos de la lista desde el final.

mi_lista=["Alegra", "Rocky", "Eroz"]

mi_lista[2]="Princesa" #Permite sustituir.
mi_lista.append("Eroz") #Permite anexar elementos a la lista.

print(mi_lista[-2]) #Permite acceder al último elemnto de la lista.

print(mi_lista[2])
print(mi_lista)

print(mi_lista[5])