"""Con la lista [10, 20, 30, 40, 50]:

    Verifica si el número 20 está en la lista.
    Encuentra el índice del número 30.
    Cuenta cuántas veces aparece el número 20.

"""

list=[10, 10, 30, 40, 50]
if 20 in list:
    print("El número 20 si está en la lista")
else:
    print("El número 20 no está en la lista")

list=[10, 10, 30, 40, 50]
indice=list.index(30)
print(indice)

cuantos=list.count(10)
print(cuantos)