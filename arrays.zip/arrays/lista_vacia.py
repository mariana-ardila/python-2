
""" ¿Cómo podemos saber si una lista no tiene elementos?

Ejemplo práctico:

Crea una lista vacía y escribe un código que imprima "La lista está vacía" si no contiene datos.
"""

vacia=[]

if i in vacia:
    print("Lista vacia")