mi_lista=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

mi_lista[1]=3
print(mi_lista)

lista=[]

lista.append(13)
print(lista)