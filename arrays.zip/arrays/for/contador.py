"""
for contador in range (10):
print(contador)
if contador==5:
break
"""

for contador in range (5):
    if contador==2:
        continue
    print(contador)
   
    