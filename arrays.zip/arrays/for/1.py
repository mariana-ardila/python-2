"""
Imprimir caracteres de una cadena:
Pide al usuario una cadena y usa un for para imprimir cada carácter de la cadena en una línea separada.
mensaje=input("Digite un mensaje")
mensaje=input("Digite un mensaje")


for i in mensaje:
    print(mensaje[i])
"""

#hallar el numero más grande en una lista.

#list=[32,42,12,67,322, 406,97,63, 67, 40, 32]

list=[59, 13,42,67, 40, 32]
mayor=0

for i in range(len(list)):
    for j in range(len(list)):
        if list[i]>=list[j]:
            mayor= list[i]
        else:
            mayor= list[j]

    
print(f"El número mayor es: {mayor}")