tantos=["A" "2" "3" "4" "5" "6" "7" "S" "C" "R"]
palos=["Oros" "Copas" "Bastos" "Espadas"]

cartas=[]

for i in (len(tantos)):
    for j in (len(palos)):
        print(f"La carta es: {tantos[i]} de {palos[j]} ")