"""
##Ordena la lista [40, 10, 30, 20]:

    Primero en orden ascendente.
    Luego en orden descendente.
    Crea una nueva lista ordenada sin modificar la original.
"""
#modifica array .sort()
list=[40, 10, 30, 20]
list.sort()
print(list)


#modifica array .sort()
list=[40, 10, 30, 20]
list.sort(reverse=True)
print(list)


list=[40, 10, 30, 20]

new_list=sorted(list)

print(new_list)
print(list)
